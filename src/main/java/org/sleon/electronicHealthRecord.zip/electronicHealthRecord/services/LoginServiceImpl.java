package org.sleon.electronicHealthRecord.services;

import org.sleon.electronicHealthRecord.services.interfaces.LoginService;

public class LoginServiceImpl implements LoginService {
    @Override
    public void authenticate(String username, String password) {

    }
}
