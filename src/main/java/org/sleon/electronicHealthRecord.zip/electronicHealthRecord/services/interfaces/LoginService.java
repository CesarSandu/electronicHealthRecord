package org.sleon.electronicHealthRecord.services.interfaces;

public interface LoginService {
    void authenticate(String username, String password);
}
