package org.sleon.electronicHealthRecord.models;

public class UsuarioHospital extends Usuario{
    protected String idUsuario;
    protected String contrasenia;

    public String getIdUsuario() {
        return idUsuario;
    }
    public void setIdUsuario(String idUsuario) {
        this.idUsuario = idUsuario;
    }
    public String getContrasenia() {
        return contrasenia;
    }
    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }
}
